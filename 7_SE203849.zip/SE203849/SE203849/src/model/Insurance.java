package model;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Insurance implements Serializable {

    private static final long serialVersionUID = 1L;

    private String insuranceId;
    private Date establishedDate;
    private String licensePlate;
    private String customerName;
    private int insurancePeriod;
    private int insuranceFee;

    public Insurance() {
    }

    public Insurance(String insuranceId, Date establishedDate,
            String licensePlate, String customerName,
            int insurancePeriod, int insuranceFee) {

        this.insuranceId = insuranceId;
        this.establishedDate = establishedDate;
        this.licensePlate = licensePlate;
        this.customerName = customerName;
        this.insurancePeriod = insurancePeriod;
        this.insuranceFee = insuranceFee;
    }

    public String getInsuranceId() {
        return insuranceId;
    }

    public void setInsuranceId(String insuranceId) {
        this.insuranceId = insuranceId;
    }

    public Date getEstablishedDate() {
        return establishedDate;
    }

    public void setEstablishedDate(Date establishedDate) {
        this.establishedDate = establishedDate;
    }

    public String getLicensePlate() {
        return licensePlate;
    }

    public void setLicensePlate(String licensePlate) {
        this.licensePlate = licensePlate;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public int getInsurancePeriod() {
        return insurancePeriod;
    }

    public void setInsurancePeriod(int insurancePeriod) {
        this.insurancePeriod = insurancePeriod;
    }

    public int getInsuranceFee() {
        return insuranceFee;
    }

    public void setInsuranceFee(int insuranceFee) {
        this.insuranceFee = insuranceFee;
    }

    @Override
    public String toString() {

        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");

        return String.format(
                "%-8s %-12s %-15s %-20s %5d %12d",
                insuranceId,
                sdf.format(establishedDate),
                licensePlate,
                customerName,
                insurancePeriod,
                insuranceFee
        );
    }
}