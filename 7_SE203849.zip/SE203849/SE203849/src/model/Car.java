package model;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Car implements Serializable {

    private static final long serialVersionUID = 1L;

    private String licensePlate;
    private String owner;
    private String brand;
    private double vehicleValue;
    private Date registrationDate;
    private String registrationPlace;
    private int vehicleType;

    public Car() {
    }

    public Car(String licensePlate, String owner, String brand,
            double vehicleValue, Date registrationDate,
            String registrationPlace, int vehicleType) {

        this.licensePlate = licensePlate;
        this.owner = owner;
        this.brand = brand;
        this.vehicleValue = vehicleValue;
        this.registrationDate = registrationDate;
        this.registrationPlace = registrationPlace;
        this.vehicleType = vehicleType;
    }

    public String getLicensePlate() {
        return licensePlate;
    }

    public void setLicensePlate(String licensePlate) {
        this.licensePlate = licensePlate;
    }

    public String getOwner() {
        return owner;
    }

    public void setOwner(String owner) {
        this.owner = owner;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public double getVehicleValue() {
        return vehicleValue;
    }

    public void setVehicleValue(double vehicleValue) {
        this.vehicleValue = vehicleValue;
    }

    public Date getRegistrationDate() {
        return registrationDate;
    }

    public void setRegistrationDate(Date registrationDate) {
        this.registrationDate = registrationDate;
    }

    public String getRegistrationPlace() {
        return registrationPlace;
    }

    public void setRegistrationPlace(String registrationPlace) {
        this.registrationPlace = registrationPlace;
    }

    public int getVehicleType() {
        return vehicleType;
    }

    public void setVehicleType(int vehicleType) {
        this.vehicleType = vehicleType;
    }

    @Override
    public String toString() {

        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");

        return String.format(
                "%-15s %-20s %-15s %12.0f %-12s %-18s %5d",
                licensePlate,
                owner,
                brand,
                vehicleValue,
                sdf.format(registrationDate),
                registrationPlace,
                vehicleType
        );
    }
}