package tools;

import business.Cars;
import business.Insurances;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;
import java.util.function.Consumer;
import java.util.function.Predicate;
import model.Car;
import model.Insurance;

public class Inputter {

    private Scanner ndl;

    public Inputter() {
        this.ndl = new Scanner(System.in);
    }

    /**
     * Nhap du lieu chuoi truc tiep tu ban phim boi nguoi dung
     */
    public String getString(String mess) {
        System.out.print(mess);
        return ndl.nextLine();
    }

    /**
     * Nhap du lieu la so nguyen tu ban phim boi nguoi dung
     */
    public int getInt(String mess) {

        int result = 0;

        String temp = getString(mess);

        if (Acceptable.isValid(temp, Acceptable.INTEGER_VALID)) {

            result = Integer.parseInt(temp);
        }

        return result;
    }

    /**
     * Nhap du lieu la so double tu ban phim boi nguoi dung
     */
    public double getDouble(String mess) {

        double result = 0;

        String temp = getString(mess);

        if (Acceptable.isValid(
                temp,
                Acceptable.DOUBLE_VALID)) {

            result = Double.parseDouble(temp);
        }

        return result;
    }

    /**
     * Phuong thuc cho phep nhap va kiem tra du lieu, nhap lai neu khong hop le.
     */
    public String inputAndLoop(String mess, String pattern, boolean isLoop) {

        String result = "";

        boolean more = true;

        do {

            result = getString(mess);

            more
                    = !Acceptable.isValid(
                            result,
                            pattern
                    );

            if (more && (isLoop && result.length() > 0)) {

                System.out.println("Data is invalid !. Re-enter ...");
            }

        } while (isLoop && more);

        return result.trim();
    }

    /**
     * Cho phep nguoi dung nhap va kiem tra du lieu, bat buoc lap den khi hop
     * le.
     */
    public String inputAndLoop(
            String mess,
            String pattern) {

        return inputAndLoop(
                mess,
                pattern,
                true
        );
    }

    /**
     * Nhap 1 truong String.
     *
     * isUpdate = false: Bat buoc nhap dung.
     *
     * isUpdate = true: Enter de giu gia tri cu. Neu nhap sai thi giu gia tri
     * cu.
     */
    private void inputStringField(
            String prompt,
            Predicate<String> validator,
            boolean isUpdate,
            Consumer<String> setter) {

        if (!isUpdate) {

            String value;

            do {

                value = getString(prompt);

                if (!validator.test(value)) {

                    System.out.println(
                            "Data is invalid !. Re-enter ..."
                    );
                }

            } while (!validator.test(value));

            setter.accept(value);

            return;
        }

        String value = getString(prompt);

        if (value.trim().isEmpty()) {

            return;
        }

        if (validator.test(value)) {

            setter.accept(value);

        } else {

            System.out.println(
                    "Invalid format ! Keeping old value."
            );
        }
    }

    // ========================================================================
    // INTEGER
    // ========================================================================
    /**
     * Bien the cua inputStringField() danh cho so nguyen duong.
     */
    private void inputIntField(
            String prompt,
            boolean isUpdate,
            Consumer<Integer> setter) {

        Predicate<String> isPositiveInt
                = s -> Acceptable.isValid(
                        s,
                        Acceptable.POSITIVE_INT_VALID
                );

        inputStringField(
                prompt,
                isPositiveInt,
                isUpdate,
                s -> setter.accept(
                        Integer.parseInt(s)
                )
        );
    }

    // ========================================================================
    // DOUBLE
    // ========================================================================
    /**
     * Bien the cua inputStringField() danh cho so double duong.
     */
    private void inputDoubleField(
            String prompt,
            boolean isUpdate,
            Consumer<Double> setter) {

        Predicate<String> isPositiveDouble
                = s -> Acceptable.isValid(
                        s,
                        Acceptable.POSITIVE_DOUBLE_VALID
                );

        inputStringField(
                prompt,
                isPositiveDouble,
                isUpdate,
                s -> setter.accept(
                        Double.parseDouble(s)
                )
        );
    }

    // ========================================================================
    // DATE
    // ========================================================================
    /**
     * Nhap ngay thang.
     *
     * Khac P01: Car Insurance chi yeu cau ngay hop le, khong bat buoc ngay
     * trong tuong lai.
     */
    private void inputDateField(
            String prompt,
            boolean isUpdate,
            Consumer<Date> setter) {

        SimpleDateFormat df
                = new SimpleDateFormat("dd/MM/yyyy");

        df.setLenient(false);

        Predicate<String> isValidDate = s -> {

            try {

                df.parse(s);

                return true;

            } catch (ParseException ex) {

                return false;
            }
        };

        inputStringField(
                prompt,
                isValidDate,
                isUpdate,
                s -> {

                    try {

                        setter.accept(
                                df.parse(s)
                        );

                    } catch (ParseException ex) {

                        // Khong xay ra
                        // vi validator da kiem tra
                    }
                }
        );
    }

    // ========================================================================
    // VEHICLE TYPE
    // ========================================================================
    /**
     * Vehicle type chi chap nhan: 5, 7, 9
     */
    private void inputVehicleType(
            String prompt,
            boolean isUpdate,
            Consumer<Integer> setter) {

        Predicate<String> validVehicleType
                = s -> {

                    if (!Acceptable.isValid(
                            s,
                            Acceptable.POSITIVE_INT_VALID)) {

                        return false;
                    }

                    int type
                    = Integer.parseInt(s);

                    return type == 5
                    || type == 7
                    || type == 9;
                };

        inputStringField(
                prompt,
                validVehicleType,
                isUpdate,
                s -> setter.accept(
                        Integer.parseInt(s)
                )
        );
    }

    // ========================================================================
    // INSURANCE PERIOD
    // ========================================================================
    /**
     * Insurance period chi chap nhan: 12, 24, 36 thang.
     */
    private void inputInsurancePeriod(
            String prompt,
            boolean isUpdate,
            Consumer<Integer> setter) {

        Predicate<String> validPeriod
                = s -> {

                    if (!Acceptable.isValid(s, Acceptable.POSITIVE_INT_VALID)) {

                        return false;
                    }

                    int period
                    = Integer.parseInt(s);

                    return period == 12
                    || period == 24
                    || period == 36;
                };

        inputStringField(
                prompt,
                validPeriod,
                isUpdate,
                s -> setter.accept(
                        Integer.parseInt(s)
                )
        );
    }

    // ========================================================================
    // FUNCTION 1, 3: CAR
    // ========================================================================
    /**
     * Nhap hoac cap nhat thong tin Car.
     *
     * License plate khong xu ly o day. Viec kiem tra trung license plate thuoc
     * ve business/dispatcher.
     *
     * Function 1: isUpdate = false
     *
     * Function 3: isUpdate = true
     */
    public void inputCarInfo(Car c, boolean isUpdate) {

        inputStringField(isUpdate ? "New owner [Enter to keep old]: " : "Car owner [2-35 chars]: ",
                s -> Acceptable.isValid(s, Acceptable.OWNER_VALID), isUpdate, c::setOwner);

        inputStringField(isUpdate ? "New car brand [Enter to keep old]: " : "Car brand: ",
                s -> Acceptable.isValid(s, Acceptable.NON_BLANK_VALID), isUpdate, c::setBrand);

        inputDoubleField(isUpdate ? "New vehicle value [Enter to keep old]: " : "Vehicle value (>999): ", isUpdate, c::setVehicleValue);

        inputDateField(isUpdate ? "New registration date [dd/MM/yyyy] [Enter to keep old]: " : "Registration date [dd/MM/yyyy]: ", isUpdate, c::setRegistrationDate);

        inputStringField(isUpdate ? "New registration place [Enter to keep old]: " : "Registration place: ",
                s -> Acceptable.isValid(s, Acceptable.NON_BLANK_VALID), isUpdate, c::setRegistrationPlace);

        inputVehicleType(isUpdate ? "New vehicle type [5/7/9] [Enter to keep old]: " : "Vehicle type [5/7/9]: ", isUpdate, c::setVehicleType);
    }

    /**
     * FUNCTION5 Nhap thong tin Insurance.
     *
     * Insurance ID: Khong xu ly trung o Inputter. Business/dispatcher se kiem
     * tra.
     *
     * License plate: Phai ton tai trong Cars.
     */
    public Insurance inputInsuranceInfo(
            Insurance i,
            Cars carList,
            boolean isUpdate) {

        if (!isUpdate) {

            inputStringField(
                    "Established date [dd/MM/yyyy]: ",
                    s -> {

                        try {

                            SimpleDateFormat df
                            = new SimpleDateFormat(
                                    "dd/MM/yyyy"
                            );

                            df.setLenient(false);

                            df.parse(s);

                            return true;

                        } catch (ParseException e) {

                            return false;
                        }
                    },
                    false,
                    s -> {

                        try {

                            SimpleDateFormat df
                            = new SimpleDateFormat(
                                    "dd/MM/yyyy"
                            );

                            df.setLenient(false);

                            i.setEstablishedDate(
                                    df.parse(s)
                            );

                        } catch (ParseException e) {
                            // Khong xay ra
                        }
                    }
            );

            inputStringField(
                    "License plate: ",
                    s -> carList.searchById(
                            s.trim()
                    ) != null,
                    false,
                    s -> i.setLicensePlate(
                            s.trim()
                    )
            );

            inputStringField(
                    "Customer name: ",
                    s -> Acceptable.isValid(
                            s,
                            Acceptable.NON_BLANK_VALID
                    ),
                    false,
                    i::setCustomerName
            );

            inputInsurancePeriod(
                    "Insurance period [12/24/36]: ",
                    false,
                    i::setInsurancePeriod
            );

        } else {

            inputDateField(
                    "New established date [dd/MM/yyyy] [Enter to keep old]: ",
                    true,
                    i::setEstablishedDate
            );

            inputStringField(
                    "New license plate [Enter to keep old]: ",
                    s -> carList.searchById(
                            s.trim()
                    ) != null,
                    true,
                    s -> i.setLicensePlate(
                            s.trim()
                    )
            );

            inputStringField(
                    "New customer name [Enter to keep old]: ",
                    s -> Acceptable.isValid(
                            s,
                            Acceptable.NON_BLANK_VALID
                    ),
                    true,
                    i::setCustomerName
            );

            inputInsurancePeriod(
                    "New insurance period [12/24/36] [Enter to keep old]: ",
                    true,
                    i::setInsurancePeriod
            );
        }

        return i;
    }

    // ========================================================================
    // CONFIRM
    // ========================================================================
    public boolean confirm(String mess) {

        while (true) {

            String answer
                    = getString(
                            mess + " (Y/N): "
                    );

            if (answer.equalsIgnoreCase("Y")) {

                return true;
            }

            if (answer.equalsIgnoreCase("N")) {

                return false;
            }

            System.out.println(
                    "Please enter Y or N."
            );
        }
    }
}
