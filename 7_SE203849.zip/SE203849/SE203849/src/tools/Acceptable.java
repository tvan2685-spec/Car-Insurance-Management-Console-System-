package tools;

public interface Acceptable {

    String OWNER_VALID = "^.{2,35}$";
    
    String DOUBLE_VALID = "^-?\\d+(\\.\\d+)?$";

    String POSITIVE_DOUBLE_VALID = "^[0-9]+(\\.[0-9]+)?$";

    String INTEGER_VALID = "^-?\\d+$";
    
    String POSITIVE_INT_VALID = "^[1-9]\\d*$";

    String NON_BLANK_VALID = ".*\\S.*";

     static boolean isValid(String data, String pattern) {
        return data != null && data.matches(pattern);
    }
}

