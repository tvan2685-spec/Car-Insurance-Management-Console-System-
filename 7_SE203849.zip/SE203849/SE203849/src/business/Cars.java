package business;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import model.Car;
import tools.FileUtils;

public class Cars extends HashMap<String, Car> implements Workable<Car> {

    private static final long serialVersionUID = 1L;

    private static final String pathFile = "carInfo.dat";

    private boolean saved = true;

    public Cars() {
        readFromFile();
    }

    @Override
    public void addNew(Car x) {

        if (x == null) {
            return;
        }

        if (!containsKey(x.getLicensePlate())) {

            put(x.getLicensePlate(), x);

            saved = false;
        }
    }

    @Override
    public void update(Car x) {

        if (x == null) {
            return;
        }

        String licensePlate = x.getLicensePlate();

        if (containsKey(licensePlate)) {

            put(licensePlate, x);

            saved = false;
        }
    }
    
    public void update(String oldLicensePlate, Car x) {

    if (x == null || oldLicensePlate == null) {
        return;
    }

    if (!containsKey(oldLicensePlate)) {
        return;
    }

    String newLicensePlate = x.getLicensePlate();

    // Nếu đổi sang biển số khác và biển số mới đã tồn tại
    if (!oldLicensePlate.equals(newLicensePlate)
            && containsKey(newLicensePlate)) {

        return;
    }

    remove(oldLicensePlate);

    put(newLicensePlate, x);

    saved = false;
}

    @Override
    public Car searchById(String x) {

        if (x == null) {
            return null;
        }

        return get(x.trim());
    }

    @Override
    public void showAll() {

        List<Car> list = new ArrayList<>(values());

        list.sort(
                Comparator.comparing(
                        Car::getLicensePlate
                )
        );

        System.out.println(
                "\n--------------------------------------------------------------------------"
        );

        System.out.printf(
                "%-15s %-20s %-15s %12s %-12s %-18s %5s%n",
                "License Plate",
                "Owner",
                "Brand",
                "Value",
                "Reg.Date",
                "Reg.Place",
                "Type"
        );

        System.out.println(
                "--------------------------------------------------------------------------"
        );

        for (Car car : list) {
            System.out.println(car);
        }

        System.out.println(
                "--------------------------------------------------------------------------"
        );
    }

    public boolean isExist(String licensePlate) {

        return containsKey(licensePlate);
    }

    public void delete(String licensePlate) {

        if (containsKey(licensePlate)) {

            remove(licensePlate);

            saved = false;
        }
    }

    public void readFromFile() {

        clear();

        List<Car> list
                = FileUtils.readFromFile(pathFile);

        if (list != null) {

            for (Car car : list) {

                put(
                        car.getLicensePlate(),
                        car
                );
            }
        }

        saved = true;
    }

    public void saveToFile() {

        List<Car> list
                = new ArrayList<>(values());

        FileUtils.saveToFile(
                list,
                pathFile
        );

        saved = true;
    }

    public boolean isSaved() {

        return saved;
    }
}
