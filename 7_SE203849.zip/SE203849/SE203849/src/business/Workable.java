package business;

public interface Workable<T> {

    public void addNew(T x);

    public void update(T x);

    public T searchById(String x);

    public void showAll();
}
