package business;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import model.Insurance;
import tools.FileUtils;

public class Insurances extends HashMap<String, Insurance>
        implements Workable<Insurance> {

    private static final long serialVersionUID = 1L;

    private static final String pathFile = "insurances.dat";

    private boolean saved = true;

    public Insurances() {
        readFromFile();
    }

    @Override
    public void addNew(Insurance x) {

        if (x == null) {
            return;
        }

        if (!containsKey(x.getInsuranceId())) {

            put(
                    x.getInsuranceId(),
                    x
            );

            saved = false;
        }
    }

    @Override
    public void update(Insurance x) {

        if (x == null) {
            return;
        }

        if (containsKey(x.getInsuranceId())) {

            put(
                    x.getInsuranceId(),
                    x
            );

            saved = false;
        }
    }
  

    @Override
    public Insurance searchById(String x) {

        if (x == null) {
            return null;
        }

        return get(x);
    }

    @Override
    public void showAll() {

        List<Insurance> list =
                new ArrayList<>(values());

        list.sort(
                Comparator.comparing(
                        Insurance::getEstablishedDate
                )
        );

        System.out.println(
                "\n---------------------------------------------------------------"
        );

        System.out.printf(
                "%-8s %-12s %-15s %-20s %5s %12s%n",
                "ID",
                "Date",
                "License Plate",
                "Customer",
                "Month",
                "Fee"
        );

        System.out.println(
                "---------------------------------------------------------------"
        );

        for (Insurance insurance : list) {

            System.out.println(insurance);
        }

        System.out.println(
                "---------------------------------------------------------------"
        );
    }

    public boolean isCarInsured(String licensePlate) {

        for (Insurance insurance : values()) {

            if (insurance.getLicensePlate()
                    .equalsIgnoreCase(licensePlate)) {

                return true;
            }
        }

        return false;
    }

    public boolean isInsuranceIdExist(String insuranceId) {

        return containsKey(insuranceId);
    }

    public void readFromFile() {

        clear();

        List<Insurance> list =
                FileUtils.readFromFile(pathFile);

        if (list != null) {

            for (Insurance insurance : list) {

                put(
                        insurance.getInsuranceId(),
                        insurance
                );
            }
        }

        saved = true;
    }

    public void saveToFile() {

        List<Insurance> list =
                new ArrayList<>(values());

        FileUtils.saveToFile(
                list,
                pathFile
        );

        saved = true;
    }

    public boolean isSaved() {

        return saved;
    }
}