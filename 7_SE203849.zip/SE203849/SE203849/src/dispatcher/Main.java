package dispatcher;

import business.Cars;
import business.Insurances;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import model.Car;
import model.Insurance;
import tools.Acceptable;
import tools.Inputter;

public class Main {

    private static Inputter ndl = new Inputter();

    private static Cars carList = new Cars();

    private static Insurances insuranceList = new Insurances();

    private static void showMainMenu() {

        System.out.println("\n===================================================");
        System.out.println("         CAR INSURANCE MANAGEMENT SYSTEM");
        System.out.println("===================================================");
        System.out.println("1. Add car information");
        System.out.println("2. Find a car");
        System.out.println("3. Update a car");
        System.out.println("4. Delete a car");
        System.out.println("5. Add an insurance statement");
        System.out.println("6. List of insurance statements");
        System.out.println("7. Report on uninsured cars");
        System.out.println("8. Save data to file");
        System.out.println("9. Load data from file");
        System.out.println("10. Report cars by brand");
        System.out.println("11. Quit");
       
        System.out.println("===================================================");
    }

// =====================================================
// FUNCTION 1
// =====================================================
    public static void addCar() {

        boolean isContinue;

        do {

            System.out.println("\n=== ADD CAR INFORMATION ===");

            String licensePlate;

            while (true) {

                licensePlate = ndl.getString("Enter license plate: ").trim();

                if (licensePlate.isEmpty()) {

                    System.out.println("License plate cannot be empty.");

                    continue;
                }

                if (carList.isExist(licensePlate)) {

                    System.out.println("License plate already exists.");

                    continue;
                }

                break;
            }

            Car car = new Car();

            car.setLicensePlate(licensePlate);

            ndl.inputCarInfo(car, false);

            carList.addNew(car);

            System.out.println("Car added successfully.");

            // Ask whether to continue or return to main menu
            String choice = ndl.getString("\nContinue adding new vehicle information? (Y/N): ");

            isContinue = choice.equalsIgnoreCase("Y");

        } while (isContinue);
    }

    // =====================================================
    // FUNCTION 2
    // =====================================================
    public static void findCar() {

        System.out.println("\n=== FIND A CAR ===");

        String licensePlate = ndl.getString("Enter license plate: ");

        Car car = carList.searchById(licensePlate);

        if (car == null) {

            System.out.println("Unregistered vehicle");

        } else {

            System.out.println("\nCar information:");

            System.out.printf("%-15s %-20s %-15s %12s %-12s %-18s %5s%n", "License Plate", "Owner", "Brand", "Value", "Reg.Date", "Reg.Place", "Type");

            System.out.println(car);
        }
    }

    // =====================================================
    // FUNCTION 3
    // =====================================================
    public static void updateCar() {

        System.out.println("\n=== UPDATE A CAR ===");

        String licensePlate = ndl.getString("Enter license plate: ").trim();

        Car oldCar = carList.searchById(licensePlate);

        if (oldCar == null) {

            System.out.println("Car does not exist.");

            return;
        }

        ndl.inputCarInfo(oldCar, true);

        carList.update(oldCar);

        System.out.println("Car updated successfully.");
    }

    // =====================================================
    // FUNCTION 4
    // =====================================================
    public static void deleteCar() {

        System.out.println("\n=== DELETE A CAR ===");

        String licensePlate = ndl.getString("Enter license plate: ");

        Car car = carList.searchById(licensePlate);

        if (car == null) {

            System.out.println("Car does not exist.");

            return;
        }

        if (insuranceList.isCarInsured(licensePlate)) {

            System.out.println("This car is registered in insurance.");

            System.out.println("Cannot delete the car.");

            return;
        }

        boolean confirm = ndl.confirm("Are you sure you want to delete this car?");

        if (!confirm) {

            System.out.println("Delete cancelled.");

            return;
        }

        carList.delete(licensePlate);

        System.out.println("Car deleted successfully.");
    }

// =====================================================
// FUNCTION 5
// =====================================================
    public static void addInsurance() {

        boolean isContinue;

        do {

            System.out.println("\n=== ADD AN INSURANCE STATEMENT ===");

            String insuranceId;

            while (true) {

                insuranceId = ndl.getString("Enter insurance ID: ").trim();

                if (insuranceId.isEmpty()) {

                    System.out.println("Insurance ID cannot be empty.");

                    continue;
                }

                if (insuranceList.isInsuranceIdExist(insuranceId)) {

                    System.out.println("Insurance ID already exists.");

                    continue;
                }

                break;
            }

            Insurance insurance = new Insurance();

            insurance.setInsuranceId(insuranceId);

            ndl.inputInsuranceInfo(insurance, carList, false);

            Car car = carList.searchById(insurance.getLicensePlate());

            int insuranceFee = calculateInsuranceFee(car.getVehicleValue(), insurance.getInsurancePeriod());

            insurance.setInsuranceFee(insuranceFee);

            insuranceList.addNew(insurance);

            System.out.println("Insurance statement added successfully.");

            System.out.println("Insurance fee: " + String.format("%,d", insuranceFee));

            String choice = ndl.getString("\nContinue adding new insurance statement? (Y/N): ");

            isContinue = choice.equalsIgnoreCase("Y");

        } while (isContinue);
    }

    // =====================================================
    // FUNCTION 6
    // =====================================================
    public static void listInsuranceStatements() {

        System.out.println("\n=== LIST OF INSURANCE STATEMENTS ===");

        int year = ndl.getInt("Enter year: ");

        System.out.println("\nSort by:");

        System.out.println("1. Insurance ID");

        System.out.println("2. Established date");

        System.out.println("3. License plate");

        System.out.println("4. Insurance period");

        int sortChoice = ndl.getInt("Choose sort field: ");

        int order = ndl.getInt("1. ASC\n 2. DESC\n Choose order: ");

        List<Insurance> list = new ArrayList<>();

        for (Insurance insurance : insuranceList.values()) {

            Date date = insurance.getEstablishedDate();

            int insuranceYear = date.getYear() + 1900;

            if (insuranceYear == year) {

                list.add(insurance);
            }
        }

        if (list.isEmpty()) {

            System.out.println("No insurance statements found.");

            return;
        }

        Comparator<Insurance> comparator;

        switch (sortChoice) {

            case 1:

                comparator = Comparator.comparing(Insurance::getInsuranceId);

                break;

            case 2:

                comparator = Comparator.comparing(Insurance::getEstablishedDate);

                break;

            case 3:

                comparator = Comparator.comparing(Insurance::getLicensePlate);

                break;

            case 4:

                comparator = Comparator.comparingInt(Insurance::getInsurancePeriod);

                break;

            default:

                System.out.println("Invalid sort field.");

                return;
        }

        if (order == 2) {

            comparator = comparator.reversed();
        }

        list.sort(comparator);

        System.out.println();

        System.out.printf(
                "%-8s %-12s %-15s %-20s %5s %12s%n",
                "ID",
                "Date",
                "License Plate",
                "Customer",
                "Month",
                "Fee"
        );

        System.out.println(
                "---------------------------------------------------------------"
        );

        for (Insurance insurance : list) {

            System.out.println(insurance);
        }
    }

    // =====================================================
    // FUNCTION 7
    // =====================================================
    public static void reportUninsuredCars() {

        System.out.println("\n=== REPORT ON UNINSURED CARS ===");

        System.out.println("Sort by:");

        System.out.println("1. License plate");

        System.out.println("2. Owner");

        System.out.println("3. Registration date");

        System.out.println("4. Vehicle type");

        int sortChoice = ndl.getInt("Choose sort field: ");

        int order = ndl.getInt("1. ASC\n 2. DESC\n Choose order: ");

        List<Car> uninsuredCars = new ArrayList<>();

        for (Car car : carList.values()) {

            if (!insuranceList.isCarInsured(car.getLicensePlate())) {

                uninsuredCars.add(car);
            }
        }

        if (uninsuredCars.isEmpty()) {

            System.out.println("All cars are insured.");

            return;
        }

        Comparator<Car> comparator;

        switch (sortChoice) {

            case 1:

                comparator = Comparator.comparing(Car::getLicensePlate);

                break;

            case 2:

                comparator = Comparator.comparing(Car::getOwner);

                break;

            case 3:

                comparator = Comparator.comparing(Car::getRegistrationDate);

                break;

            case 4:

                comparator = Comparator.comparingInt(Car::getVehicleType);

                break;

            default:

                System.out.println("Invalid sort field.");

                return;
        }

        if (order == 2) {

            comparator = comparator.reversed();
        }

        uninsuredCars.sort(comparator);

        System.out.printf(
                "%-15s %-20s %-15s %12s %-12s %-18s %5s%n",
                "License Plate",
                "Owner",
                "Brand",
                "Value",
                "Reg.Date",
                "Reg.Place",
                "Type"
        );

        System.out.println(
                "--------------------------------------------------------------------------"
        );

        for (Car car : uninsuredCars) {

            System.out.println(car);
        }
    }

    // =====================================================
    // FUNCTION 8
    // =====================================================
    public static void saveData() {

        System.out.println("\n=== SAVE DATA ===");

        carList.saveToFile();

        insuranceList.saveToFile();

        System.out.println("Data saved successfully.");
    }

    // =====================================================
    // FUNCTION 9
    // =====================================================
    public static void loadData() {

        System.out.println("\n=== LOAD DATA ===");

        carList.readFromFile();

        insuranceList.readFromFile();

        System.out.println("Data loaded successfully.");
    }

    // =====================================================
    // FUNCTION 10
    // =====================================================
    public static boolean quit() {

        System.out.println("\n=== QUIT ===");

        boolean changed = !carList.isSaved() || !insuranceList.isSaved();

        if (changed) {

            System.out.println("Data has been changed but not saved.");

            boolean save = ndl.confirm("Do you want to save before quitting?");

            if (save) {

                saveData();
            }
        }

        boolean quit = ndl.confirm("Are you sure you want to quit?");

        return quit;
    }
// =====================================================
// FUNCTION 11
// 
// =====================================================
public static void reportCarsByBrand() {

    System.out.println("\n=== REPORT CARS BY BRAND ===");

    // 1. Input brand
    String brand = ndl.getString("Enter car brand: ").trim();

    if (brand.isEmpty()) {
        System.out.println("Brand cannot be empty.");
        return;
    }

    // 2. Find cars by brand
    List<Car> list = new ArrayList<>();

    for (Car car : carList.values()) {
        if (car.getBrand() != null
                && car.getBrand().trim()
                        .equalsIgnoreCase(brand)) {

            list.add(car);
        }
    }

    // 3. No car found
    if (list.isEmpty()) {
        System.out.println("No car of this brand");
        return;
    }

    // 4. Sort by vehicle value DESC
    list.sort(
        Comparator.comparingDouble(Car::getVehicleValue)
                  .reversed()
    );

    // 5. Display table
    System.out.println(
        "---------------------------------------------------------------"
    );

    System.out.printf(
        "%-5s %-15s %-20s %-13s %15s %-10s%n",
        "No.",
        "License plate",
        "Owner",
        "Vehicle type",
        "Value",
        "Insured"
    );

    System.out.println(
        "---------------------------------------------------------------"
    );

    int total = 0;
    int insured = 0;
    int uninsured = 0;
    int no = 1;

    for (Car car : list) {

        boolean isInsured =
                insuranceList.isCarInsured(
                        car.getLicensePlate()
                );

        String insuranceStatus =
                isInsured ? "Yes" : "No";

        System.out.printf(
            "%-5d %-15s %-20s %-13d %,15.0f %-10s%n",
            no++,
            car.getLicensePlate(),
            car.getOwner(),
            car.getVehicleType(),
            car.getVehicleValue(),
            insuranceStatus
        );

        total++;

        if (isInsured) {
            insured++;
        } else {
            uninsured++;
        }
    }

    System.out.println(
        "---------------------------------------------------------------"
    );

    // 6. Statistics
    System.out.printf(
        "Total: %d car(s) | Insured: %d | Uninsured: %d%n",
        total,
        insured,
        uninsured
    );
}
    // =====================================================
    // CALCULATE INSURANCE FEE
    // =====================================================
    public static int calculateInsuranceFee(
            double vehicleValue,
            int insurancePeriod) {

        double fee = 0;

        switch (insurancePeriod) {

            case 12:

                fee = vehicleValue * 0.25;

                break;

            case 24:

                fee = vehicleValue * 0.20 * 2;

                break;

            case 36:

                fee = vehicleValue * 0.15 * 3;

                break;
        }

        return (int) Math.round(fee);
    }

    // =====================================================
    // FORMAT DATE
    // =====================================================
    public static String formatDate(Date date) {

        if (date == null) {
            return "";
        }

        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");

        return sdf.format(date);
    }

    // =====================================================
    // MAIN
    // =====================================================
    public static void main(String[] args) {

        int choice;

        do {

            showMainMenu();

            choice = ndl.getInt("Enter your choice: ");

            switch (choice) {

                case 1:

                    addCar();

                    break;

                case 2:

                    findCar();

                    break;

                case 3:

                    updateCar();

                    break;

                case 4:

                    deleteCar();

                    break;

                case 5:

                    addInsurance();

                    break;

                case 6:

                    listInsuranceStatements();

                    break;

                case 7:

                    reportUninsuredCars();

                    break;

                case 8:

                    saveData();

                    break;

                case 9:

                    loadData();

                    break;
                case 10:
                    reportCarsByBrand();
                    
                    break;
                case 11:

                    if (quit()) {

                        System.out.println("Goodbye!");

                        return;
                    }

                    break;

                default:

                    System.out.println("Invalid choice.");
            }

        } while (true);
    }
}
